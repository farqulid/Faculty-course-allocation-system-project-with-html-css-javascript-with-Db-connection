<?php
include("dbConnect.php");
include("AdminDashboard.php");

if (isset($_POST["btnSearch"])) {
    $facultyName = $_POST["search"];

    $sql = "SELECT * FROM faculty WHERE FacultyName='$facultyName'";
    $result = mysqli_query($conn, $sql);

    if (!empty($facultyName) && mysqli_num_rows($result) > 0) {
        echo "<div class='main'>";
        echo '<div class="container">';
        echo "<center><h2>Data for Faculty Name:</h2> $facultyName </center><br>";

        $days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];

        foreach ($days as $day) {
            echo "<strong>$day:</strong><br>";

            // $timeSlots = [
            //     "08:00:00-08:30:00", "08:30:00-09:00:00", "09:00:00-09:30:00", "09:30:00-10:00:00",
            //     "10:00:00-10:30:00", "10:30:00-11:00:00", "11:00:00-11:30:00", "11:30:00-12:00:00",
            //     "12:00:00-12:30:00", "12:30:00-13:00:00", "13:00:00-13:30:00", "13:30:00-14:00:00",
            //     "14:00:00-14:30:00", "14:30:00-15:00:00", "15:00:00-15:30:00", "15:30:00-16:00:00",
            //     "16:00:00-16:30:00", "16:30:00-17:00:00",
            // ];

            $timeSlots = [
                "08:00:00-09:30:00", "08:00:00-10:00:00", "08:00:00-11:00:00", "09:30:00-11:00:00",
                "10:00:00-12:00:00", "11:00:00-12:30:00", "11:00:00-14:00:00", 
                "12:00:00-14:00:00", "12:30:00-14:00:00", 
                "13:00:00-14:30:00",
                "14:00:00-16:00:00", "14:00:00-15:30:00", "14:00:00-17:00:00"
            ];

            foreach ($timeSlots as $timeSlot) {
                $query = "SELECT c.CourseName, s.Sec, s.startTime, s.endTime
                          FROM section s
                          JOIN course c ON s.CourseID = c.CourseID
                          JOIN faculty f ON s.FacultyID = f.FacultyID
                          WHERE s.Day = '$day' 
                          AND s.startTime = SUBSTRING_INDEX('$timeSlot', '-', 1)
                          AND s.endTime = SUBSTRING_INDEX('$timeSlot', '-', -1)
                          AND f.FacultyName = '$facultyName'";
                $result = mysqli_query($conn, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $courseName = $row['CourseName'];
                        $section = $row['Sec'];
                        $classTime = $row['startTime'] . '-' . $row['endTime'];
                        echo "$courseName - [$section] : $classTime<br>";
                    }
                }
            }

            echo "<br>";
        }

        echo '</div></div>';
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>TSF</title>
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.min.css">
    <script src="bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
    <script src="bootstrap-5.3.2-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="CSS/style.css">
</head>

<body>
    <div class="main">
        <div class="container">
            <form method="POST">
                <br><center><h2>Faculty TSF</h2></center>

                <?php
                echo "
                <input type='text' class='form-control' name='search' placeholder='Search by faculty name'><br>";
                echo '<button name="btnSearch" class="btn btn-primary">Search</button>';
                ?>

            </form>
        </div>
    </div>
</body>

</html>
